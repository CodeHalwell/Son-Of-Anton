//! Integration tests for the personal-mode GitHub client (Phase 3 STEP 3.1),
//! driven against a `wiremock` mock of the GitHub REST API.
//!
//! The focus is the behavior that is hard to get right and easy to regress:
//! idempotent creates (list-before-create finds a prior object by its hidden
//! marker), the token never entering any serializable/loggable surface, and
//! non-2xx responses mapping to a typed API error.

use codypendent_integrations::github::idempotency;
use codypendent_integrations::github::model::{NewCheckRun, NewPullRequest, UpdatePullRequest};
use codypendent_integrations::github::{
    GitHubApi, GitHubError, GitHubToken, RepoId, RestGitHubClient,
};
use wiremock::matchers::{body_partial_json, method, path, query_param};
use wiremock::{Mock, MockServer, ResponseTemplate};

const SENTINEL_TOKEN: &str = "ghp_SEKRET";

fn client(server: &MockServer) -> RestGitHubClient {
    RestGitHubClient::new(server.uri(), GitHubToken::new(SENTINEL_TOKEN)).expect("build client")
}

fn pr_json(number: u64, body: &str) -> serde_json::Value {
    serde_json::json!({
        "number": number,
        "title": "Add feature",
        "body": body,
        "state": "open",
        "draft": true,
        "html_url": "https://example.test/pull/1",
        "head": { "ref": "feature" },
        "base": { "ref": "main" }
    })
}

fn comment_json(id: u64, body: &str) -> serde_json::Value {
    serde_json::json!({
        "id": id,
        "body": body,
        "user": { "login": "octocat" }
    })
}

#[tokio::test]
async fn idempotent_draft_pr() {
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let key = "draft-pr-idem-key";
    let created_body = idempotency::body_with_marker("draft pr", key);

    // First list returns []: nothing exists yet, so the client creates.
    Mock::given(method("GET"))
        .and(path("/repos/o/r/pulls"))
        .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!([])))
        .up_to_n_times(1)
        .with_priority(1)
        .mount(&server)
        .await;

    // Subsequent lists return the created PR, marker and all.
    Mock::given(method("GET"))
        .and(path("/repos/o/r/pulls"))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_json(serde_json::json!([pr_json(1, &created_body)])),
        )
        .with_priority(2)
        .mount(&server)
        .await;

    // The create endpoint must be hit at most once across both calls.
    Mock::given(method("POST"))
        .and(path("/repos/o/r/pulls"))
        .respond_with(ResponseTemplate::new(201).set_body_json(pr_json(1, &created_body)))
        .expect(1)
        .mount(&server)
        .await;

    let gh = client(&server);
    let req = NewPullRequest::draft("Add feature", "feature", "main");

    let first = gh
        .create_draft_pull_request(&repo, &req, key)
        .await
        .expect("first create");
    let second = gh
        .create_draft_pull_request(&repo, &req, key)
        .await
        .expect("second create");

    assert_eq!(first.number, 1);
    assert_eq!(second.number, 1, "retry must find the existing PR");
    // `.expect(1)` on the POST mock is verified when `server` drops.
}

#[tokio::test]
async fn create_review_comment_is_idempotent() {
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let key = "comment-idem-key";
    let created_body = idempotency::body_with_marker("please fix", key);

    Mock::given(method("GET"))
        .and(path("/repos/o/r/issues/1/comments"))
        .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!([])))
        .up_to_n_times(1)
        .with_priority(1)
        .mount(&server)
        .await;

    Mock::given(method("GET"))
        .and(path("/repos/o/r/issues/1/comments"))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_json(serde_json::json!([comment_json(7, &created_body)])),
        )
        .with_priority(2)
        .mount(&server)
        .await;

    Mock::given(method("POST"))
        .and(path("/repos/o/r/issues/1/comments"))
        .respond_with(ResponseTemplate::new(201).set_body_json(comment_json(7, &created_body)))
        .expect(1)
        .mount(&server)
        .await;

    let gh = client(&server);

    let first = gh
        .create_review_comment(&repo, 1, "please fix", key)
        .await
        .expect("first comment");
    let second = gh
        .create_review_comment(&repo, 1, "please fix", key)
        .await
        .expect("second comment");

    assert_eq!(first.id, 7);
    assert_eq!(second.id, 7, "retry must find the existing comment");
}

#[test]
fn token_never_serialized() {
    // The token's Debug is redacted.
    let token = GitHubToken::new(SENTINEL_TOKEN);
    let debug = format!("{token:?}");
    assert!(
        !debug.contains(SENTINEL_TOKEN),
        "Debug leaked the token: {debug}"
    );

    // No serializable model type carries the token: serializing request bodies
    // can never surface it, because it is not a field of any of them.
    let new_pr = NewPullRequest::draft("t", "feature", "main");
    let update = UpdatePullRequest {
        title: Some("t".to_string()),
        body: Some("b".to_string()),
        state: Some("open".to_string()),
    };
    let check = NewCheckRun {
        name: "ci".to_string(),
        head_sha: "abc123".to_string(),
        summary: "ok".to_string(),
        conclusion: Some("success".to_string()),
        external_id: Some("key".to_string()),
    };
    for value in [
        serde_json::to_string(&new_pr).expect("serialize new pr"),
        serde_json::to_string(&update).expect("serialize update"),
        serde_json::to_string(&check).expect("serialize check"),
    ] {
        assert!(
            !value.contains(SENTINEL_TOKEN),
            "a model serialization contained the token: {value}"
        );
    }
}

#[tokio::test]
async fn http_error_maps() {
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");

    Mock::given(method("GET"))
        .and(path("/repos/o/r/pulls/999"))
        .respond_with(ResponseTemplate::new(404).set_body_string("Not Found"))
        .mount(&server)
        .await;

    let gh = client(&server);
    let err = gh
        .get_pull_request(&repo, 999)
        .await
        .expect_err("404 must be an error");

    match err {
        GitHubError::Api { status, .. } => assert_eq!(status, 404),
        other => panic!("expected GitHubError::Api {{ status: 404 }}, got {other:?}"),
    }
}

#[tokio::test]
async fn hostile_path_parameters_are_refused_before_any_request() {
    // No mocks mounted: a request reaching the server would 404 into
    // GitHubError::Api. The refusal must be InvalidParameter, proving the
    // request was never built — a traversal ref like this would otherwise
    // normalize into a DIFFERENT api.github.com endpoint under the user's token.
    let server = MockServer::start().await;
    let gh = client(&server);

    let traversal = RepoId::new("o", "r");
    let err = gh
        .list_check_runs(&traversal, "x/../../../../repos/evil/evil/issues")
        .await
        .expect_err("a traversal ref must be refused");
    assert!(matches!(
        err,
        GitHubError::InvalidParameter { kind: "ref", .. }
    ));

    let bad_owner = RepoId::new("o/../evil", "r");
    let err = gh
        .get_pull_request(&bad_owner, 1)
        .await
        .expect_err("a slash-bearing owner must be refused");
    assert!(matches!(
        err,
        GitHubError::InvalidParameter { kind: "owner", .. }
    ));

    let query_ref = RepoId::new("o", "r");
    let err = gh
        .list_check_runs(&query_ref, "HEAD?per_page=1")
        .await
        .expect_err("a query-injecting ref must be refused");
    assert!(matches!(
        err,
        GitHubError::InvalidParameter { kind: "ref", .. }
    ));

    // Ordinary parameters still pass validation (the call then 404s at the
    // mockless server, proving the request WAS built and sent).
    let err = gh
        .list_check_runs(&query_ref, "feature/branch-1.2")
        .await
        .expect_err("no mock mounted");
    assert!(matches!(err, GitHubError::Api { .. }));
}

#[tokio::test]
async fn check_run_summary_nests_output_and_is_idempotent() {
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let key = "abc:ci";

    let check_run_json = serde_json::json!({
        "id": 9,
        "name": "ci",
        "status": "completed",
        "conclusion": "success",
        "external_id": key,
    });

    // First list: no runs on the commit yet, so the client creates.
    Mock::given(method("GET"))
        .and(path("/repos/o/r/commits/abc/check-runs"))
        .respond_with(
            ResponseTemplate::new(200).set_body_json(serde_json::json!({ "check_runs": [] })),
        )
        .up_to_n_times(1)
        .with_priority(1)
        .mount(&server)
        .await;

    // Later lists serve the created run, external_id marker and all.
    Mock::given(method("GET"))
        .and(path("/repos/o/r/commits/abc/check-runs"))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_json(serde_json::json!({ "check_runs": [check_run_json] })),
        )
        .with_priority(2)
        .mount(&server)
        .await;

    // The POST must carry the wire shape GitHub actually reads — the summary
    // nested under `output` (a flat top-level `summary` is silently ignored by
    // the real API) plus the replay marker as `external_id` — and be hit at
    // most once across both calls.
    Mock::given(method("POST"))
        .and(path("/repos/o/r/check-runs"))
        .and(body_partial_json(serde_json::json!({
            "name": "ci",
            "head_sha": "abc",
            "conclusion": "success",
            "external_id": key,
            "output": { "title": "ci", "summary": "all green" },
        })))
        .respond_with(ResponseTemplate::new(201).set_body_json(check_run_json.clone()))
        .expect(1)
        .mount(&server)
        .await;

    let gh = client(&server);
    let req = NewCheckRun {
        name: "ci".to_string(),
        head_sha: "abc".to_string(),
        summary: "all green".to_string(),
        conclusion: Some("success".to_string()),
        external_id: None,
    };

    let first = gh
        .create_check_run_summary(&repo, &req, key)
        .await
        .expect("first create");
    let second = gh
        .create_check_run_summary(&repo, &req, key)
        .await
        .expect("second create");

    assert_eq!(first.id, 9);
    assert_eq!(
        second.id, 9,
        "retry must find the existing check run by external_id"
    );
    // `.expect(1)` on the POST mock is verified when `server` drops.
}

#[tokio::test]
async fn pagination_refuses_lookalike_origin_next_links() {
    // A hostile `Link: rel="next"` pointing at a prefix-lookalike host
    // (`<base>.evil.test`) must not be followed — the follow-up request would
    // carry the bearer token to the attacker. The mock returns such a link on
    // the first page; the client must stop after page one rather than error or
    // leak a second request (which would fail to resolve anyway).
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let evil_next = format!(
        "{}.evil.test/repos/o/r/issues/1/comments?page=2",
        server.uri()
    );

    Mock::given(method("GET"))
        .and(path("/repos/o/r/issues/1/comments"))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_json(serde_json::json!([comment_json(1, "first page")]))
                .insert_header("link", format!("<{evil_next}>; rel=\"next\"").as_str()),
        )
        .expect(1)
        .mount(&server)
        .await;

    let gh = client(&server);
    let comments = gh
        .list_review_comments(&repo, 1)
        .await
        .expect("list first page");
    assert_eq!(
        comments.len(),
        1,
        "the lookalike next link must not be followed"
    );
}

#[tokio::test]
async fn check_run_idempotency_scans_past_the_first_page() {
    // GitHub's default page is 30 (we ask for 100); a busy commit can push the
    // external_id marker beyond page one. The scan must follow rel="next" —
    // stopping at the first page would treat a retry as new and duplicate the
    // create. No POST mock is mounted: reaching the create endpoint would 404
    // into an Api error and fail this test.
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let key = "abc:ci";

    let filler: Vec<serde_json::Value> = (0..100)
        .map(|i| {
            serde_json::json!({
                "id": i,
                "name": format!("job-{i}"),
                "status": "completed",
                "conclusion": "success",
                "external_id": "",
            })
        })
        .collect();
    let next = format!(
        "{}/repos/o/r/commits/abc/check-runs?per_page=100&page=2",
        server.uri()
    );

    Mock::given(method("GET"))
        .and(path("/repos/o/r/commits/abc/check-runs"))
        .and(query_param("page", "2"))
        .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!({
            "check_runs": [{
                "id": 999,
                "name": "ci",
                "status": "completed",
                "conclusion": "success",
                "external_id": key,
            }]
        })))
        .with_priority(1)
        .mount(&server)
        .await;
    Mock::given(method("GET"))
        .and(path("/repos/o/r/commits/abc/check-runs"))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_json(serde_json::json!({ "check_runs": filler }))
                .insert_header("link", format!("<{next}>; rel=\"next\"").as_str()),
        )
        .with_priority(2)
        .mount(&server)
        .await;

    let gh = client(&server);
    let req = NewCheckRun {
        name: "ci".to_string(),
        head_sha: "abc".to_string(),
        summary: "s".to_string(),
        conclusion: Some("success".to_string()),
        external_id: None,
    };
    let found = gh
        .create_check_run_summary(&repo, &req, key)
        .await
        .expect("the page-2 marker must be found without creating");
    assert_eq!(found.id, 999);
}

/// A repo with more pull requests than the scan's page bound must still be
/// able to create one.
///
/// Reaching the bound used to refuse the whole operation. The refusal fired
/// before the match loop ran, so on any repo with more than 1000 lifetime pull
/// requests `create_draft_pull_request` failed deterministically — forever,
/// with the bound receding further on every new PR. A bound that turns a
/// mature repository into a permanently broken one is worse than the duplicate
/// it was guarding against.
#[tokio::test]
async fn a_repo_deeper_than_the_page_bound_can_still_open_a_pr() {
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let key = "deep-repo-key";

    // Every list page advertises another one, so the scan runs into its bound
    // no matter how far it goes — a repo with more history than the window.
    let next_link = format!("<{}/repos/o/r/pulls?page=99>; rel=\"next\"", server.uri());
    Mock::given(method("GET"))
        .and(path("/repos/o/r/pulls"))
        .respond_with(
            ResponseTemplate::new(200)
                .insert_header("link", next_link.as_str())
                .set_body_json(serde_json::json!([pr_json(7, "an unrelated pull request")])),
        )
        .mount(&server)
        .await;

    Mock::given(method("POST"))
        .and(path("/repos/o/r/pulls"))
        .respond_with(
            ResponseTemplate::new(201)
                .set_body_json(pr_json(42, &idempotency::body_with_marker("draft pr", key))),
        )
        .expect(1)
        .mount(&server)
        .await;

    let gh = client(&server);
    let req = NewPullRequest::draft("Add feature", "feature", "main");

    let created = gh
        .create_draft_pull_request(&repo, &req, key)
        .await
        .expect("a deep repo must not be permanently unable to open a PR");
    assert_eq!(created.number, 42);
}

/// A prior PR carrying the key counts even once it is closed.
///
/// The scan's own comment said so — "a closed marked PR still proves the
/// create happened" — while the condition beneath it required `state ==
/// "open"`, so closing the PR made the marker invisible and the next call
/// created a duplicate. That is the exact failure the scan exists to prevent.
#[tokio::test]
async fn a_closed_pull_request_still_proves_the_create_happened() {
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let key = "closed-pr-key";
    let marked = idempotency::body_with_marker("draft pr", key);

    let mut closed = pr_json(11, &marked);
    closed["state"] = serde_json::Value::String("closed".to_string());

    Mock::given(method("GET"))
        .and(path("/repos/o/r/pulls"))
        .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!([closed])))
        .mount(&server)
        .await;

    // No POST mock is mounted: a create here is an unmatched request and fails
    // the test, which is the assertion.
    let gh = client(&server);
    let req = NewPullRequest::draft("Add feature", "feature", "main");

    let found = gh
        .create_draft_pull_request(&repo, &req, key)
        .await
        .expect("the closed PR carrying the key is the idempotent answer");
    assert_eq!(found.number, 11);
    assert_eq!(found.state, "closed");
}

/// The scan asks for newest-first explicitly. Its window is bounded, so which
/// end of the history it covers is the difference between finding a recent
/// marker and duplicating the PR.
#[tokio::test]
async fn the_idempotency_scan_asks_for_the_newest_pull_requests_first() {
    let server = MockServer::start().await;
    let repo = RepoId::new("o", "r");
    let key = "ordering-key";

    Mock::given(method("GET"))
        .and(path("/repos/o/r/pulls"))
        .and(query_param("state", "all"))
        .and(query_param("sort", "created"))
        .and(query_param("direction", "desc"))
        .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!([])))
        .expect(1)
        .mount(&server)
        .await;

    Mock::given(method("POST"))
        .and(path("/repos/o/r/pulls"))
        .respond_with(
            ResponseTemplate::new(201)
                .set_body_json(pr_json(1, &idempotency::body_with_marker("draft pr", key))),
        )
        .mount(&server)
        .await;

    let gh = client(&server);
    let req = NewPullRequest::draft("Add feature", "feature", "main");
    gh.create_draft_pull_request(&repo, &req, key)
        .await
        .expect("create");
    // The query-param matchers above are the assertion; `.expect(1)` is
    // verified when `server` drops.
}
