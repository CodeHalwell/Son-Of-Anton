//! The built-in tool registrations (Chapter 05, STEP 2.2).
//!
//! Phase 1 shipped five tools as plain code; Phase 2 registers them as governed
//! [`RegistryItem`]s so retrieval can rank them alongside skills and disclose
//! their permissions. The names and behaviours here mirror the runtime's real
//! tools (`crates/runtime/src/tools/`): `workspace.read_file`, `workspace.search`,
//! `shell.run`, `git.diff`, and `git.apply_patch`.
//!
//! Every built-in is [`System`](Scope::System)-scoped, [`BuiltIn`](Provenance::BuiltIn),
//! [`FirstParty`](TrustTier::FirstParty), and executable (built-ins ship no
//! scripts). Each one's [`RiskClass`] is derived from its declared permissions,
//! never set by hand, so the ranking penalty and the disclosure signal stay
//! consistent with skills.

use chrono::Utc;
use codypendent_protocol::RegistryItemId;
use sqlx::SqlitePool;

use crate::registry::{Registry, RegistryError};
use crate::types::{
    CapabilityRequest, Provenance, RegistryItem, RegistryItemKind, RegistryStatus, RiskClass,
    Scope, TrustMetadata, TrustTier, Version,
};

/// The version stamped on every built-in tool registration.
const BUILTIN_VERSION: &str = "1.0.0";

/// The scope root a built-in reads or writes within, expanded to the concrete
/// path by the policy engine at grant time.
const REPOSITORY_ROOT: &str = "$REPOSITORY";
/// The mutable worktree root the Git tools operate on.
const WORKTREE_ROOT: &str = "$WORKTREE";

/// The built-in tools as governed registry items: the five Phase-1 tools
/// (`workspace.read_file`, `workspace.search`, `shell.run`, `git.diff`,
/// `git.apply_patch`), the Phase-5 `repository.test` verification tool (T6), and
/// the two Phase-5 blackboard tools (STEP 5.3).
///
/// Ids are freshly minted here; [`register_builtins`] reuses any existing id for
/// the same identity so a built-in's id is stable across restarts.
#[must_use]
pub fn builtin_tools() -> Vec<RegistryItem> {
    vec![
        tool(
            "workspace.read_file",
            "Return a line-numbered excerpt of a file, confined to the granted read scope.",
            &["read a file", "inspect source", "view file contents"],
            &["file", "read", "excerpt", "source", "view"],
            vec![CapabilityRequest::FilesystemRead(REPOSITORY_ROOT.into())],
        ),
        tool(
            "workspace.search",
            "Search the granted scope with ripgrep, returning typed file/line matches.",
            &[
                "search the codebase",
                "find a symbol",
                "grep for text",
                "locate a definition",
            ],
            &["search", "grep", "ripgrep", "find", "pattern"],
            vec![CapabilityRequest::FilesystemRead(REPOSITORY_ROOT.into())],
        ),
        tool(
            "shell.run",
            "Run an allow-listed program with a structured request in an empty environment, \
             spilling full output to the artifact store and returning a salient view.",
            &[
                "run a command",
                "run the tests",
                "build the project",
                "execute a program",
            ],
            &["shell", "command", "run", "execute", "cargo", "process"],
            // The concrete program set is the granted command allow-list; `*`
            // denotes "any allow-listed program" for the registry card.
            vec![CapabilityRequest::Command("*".into())],
        ),
        tool(
            "git.diff",
            "Produce the worktree's unstaged diff via `git diff`, spilling the full diff to the \
             artifact store. Read-only — it never mutates the worktree.",
            &[
                "show the diff",
                "inspect changes",
                "review the worktree diff",
            ],
            &["git", "diff", "changes", "worktree", "review"],
            vec![
                CapabilityRequest::FilesystemRead(WORKTREE_ROOT.into()),
                CapabilityRequest::Command("git".into()),
            ],
        ),
        tool(
            "git.apply_patch",
            "Apply a unified-diff patch to the worktree with `git apply`, running `git apply \
             --check` first and refusing (touching nothing) if the patch does not apply.",
            &["apply a patch", "modify files with a patch", "make an edit"],
            &["git", "patch", "apply", "edit", "change"],
            vec![
                CapabilityRequest::FilesystemWrite(WORKTREE_ROOT.into()),
                CapabilityRequest::Command("git".into()),
            ],
        ),
        // The structured write tools. They were advertised to the model from the
        // day they shipped but never registered, so the funnel that is supposed
        // to SELECT tools could not rank, card, or disclose the two tools an
        // agent writes files with — the sharpest instance of the two-universes
        // split. Registered here so ranking sees the same catalog dispatch does.
        tool(
            "workspace.write_file",
            "Create or overwrite a file in the worktree with exact contents, as structured \
             arguments rather than a diff. Parent directories are created; the write is \
             confined to the granted write scope.",
            &[
                "write a file",
                "create a new file",
                "overwrite a file",
                "save this content to a file",
            ],
            &["file", "write", "create", "overwrite", "save", "new"],
            vec![CapabilityRequest::FilesystemWrite(WORKTREE_ROOT.into())],
        ),
        tool(
            "workspace.edit_file",
            "Replace an exact, unique snippet of an existing file with new text — a targeted \
             edit that refuses ambiguous or missing context instead of guessing.",
            &[
                "edit a file",
                "change a line in a file",
                "replace text in a file",
                "make a targeted edit",
            ],
            &["file", "edit", "replace", "modify", "snippet", "change"],
            vec![CapabilityRequest::FilesystemWrite(WORKTREE_ROOT.into())],
        ),
        // The agent's window back onto this very registry. Registering it makes
        // the escape hatch itself discoverable — a narrowed advertisement can
        // always be widened by asking what else exists.
        tool(
            "skills.search",
            "Search the registry for the tools and skills that fit a task and read a returned \
             skill's procedure. Use it when the offered tools do not obviously cover the work.",
            &[
                "what tools are available",
                "find a skill for this task",
                "search the registry",
                "is there a skill for this",
            ],
            &["skill", "search", "registry", "discover", "catalog", "tool"],
            Vec::new(),
        ),
        tool(
            "web.search",
            "Search the public web and return ranked results with titles, URLs, and snippets. \
             Reaches the network through the configured search provider.",
            &[
                "search the web",
                "look this up online",
                "find documentation on the internet",
            ],
            &["web", "search", "internet", "online", "lookup", "browse"],
            vec![CapabilityRequest::Network("*".into())],
        ),
        // The Phase-5 workflow verification tool (T6): a workflow **tool node**
        // runs the repository's own test command in its worktree through the same
        // sandboxed process-spawn path as `shell.run`, returning a structured
        // result a `test_result` blackboard artifact is built from. The concrete
        // program is the granted command allow-list (`*` = any allow-listed
        // program), so its risk mirrors `shell.run`.
        tool(
            "repository.test",
            "Run the repository's own test command (detected from Cargo.toml / package.json / \
             pyproject.toml, or a `.codypendent/test-command` override) in the workflow node's \
             worktree, returning the exit status and captured output as a verification result.",
            &[
                "run the repository tests",
                "verify a change",
                "check the tests pass",
                "run the test suite",
            ],
            &["test", "verify", "repository", "cargo", "pytest", "check"],
            vec![
                CapabilityRequest::FilesystemRead(WORKTREE_ROOT.into()),
                CapabilityRequest::Command("*".into()),
            ],
        ),
        // The Phase-5 blackboard tools (STEP 5.3): a workflow agent's only channel
        // for sharing typed results. They target the run's own artifact board — not
        // the filesystem, a command, the network, or a secret — so they request no
        // capability (risk `Safe`); their access is gated by being offered solely
        // inside a workflow node, not by a policy scope. Registered here so they
        // render in the Skill Studio alongside the other built-ins.
        tool(
            "blackboard.post",
            "Post a typed artifact (finding, decision, hypothesis, code_location, proposed_patch, \
             test_result, document_draft, open_question) to the workflow blackboard so downstream \
             agents can build on it. Claim-like kinds require evidence; pass `supersedes` to \
             correct a prior artifact. Available only inside a workflow agent node.",
            &[
                "post a finding to the blackboard",
                "record a decision for other agents",
                "share a result with the workflow",
                "supersede a prior blackboard artifact",
            ],
            &[
                "blackboard",
                "post",
                "finding",
                "artifact",
                "workflow",
                "handoff",
            ],
            Vec::new(),
        ),
        tool(
            "blackboard.query",
            "Read the workflow blackboard — the typed artifacts other agents posted — optionally \
             filtered by kind. Available only inside a workflow agent node.",
            &[
                "read the blackboard",
                "see what other agents found",
                "query workflow findings",
                "check the blackboard for decisions",
            ],
            &[
                "blackboard",
                "query",
                "read",
                "findings",
                "workflow",
                "artifacts",
            ],
            Vec::new(),
        ),
        // Durable coordination tools already implemented by the runtime. These
        // registry cards make natural-language chat retrieval surface the same
        // typed capabilities as the TUI; agents should use them instead of
        // telling the operator to open a pane.
        tool(
            "workflow.query",
            "Inspect a persisted executable workflow run: list recent repository runs, or read one run's DAG, node state, dependencies, and cost. This reads coordination state; it does not create or start a workflow.",
            &[
                "show workflow progress",
                "inspect the executable workflow graph",
                "list recent workflow runs",
            ],
            &["workflow", "query", "dag", "graph", "persisted", "run"],
            Vec::new(),
        ),
        tool(
            "workflow.create",
            "Create and compile a structured workflow manifest, preview it for explicit approval, then atomically save it in the user's workflow library. The tool accepts typed fields, never raw YAML or an arbitrary path.",
            &[
                "create a workflow",
                "save an automation",
                "turn this process into a reusable workflow",
            ],
            &["workflow", "create", "automation", "manifest", "persist"],
            Vec::new(),
        ),
        tool(
            "workflow.run",
            "Start a named saved workflow or a structured inline workflow in the current repository. The validated launch is explicitly approval-gated and returns a durable run id for workflow.query.",
            &[
                "run the workflow",
                "start an automation",
                "execute this workflow here",
            ],
            &["workflow", "run", "start", "automation", "durable"],
            Vec::new(),
        ),
        tool(
            "task.create",
            "Create a typed task card on the repository Kanban board. Gather the title and any assignee/status first; the policy trace previews the board write before persistence.",
            &["create a Kanban task", "add this to the backlog", "make a task card"],
            &["task", "create", "kanban", "board", "backlog"],
            Vec::new(),
        ),
        tool(
            "task.update",
            "Update a repository Kanban task's title, description, assignee, or ordering through a typed, policy-traced supersession.",
            &["edit a task", "assign a Kanban card", "update the backlog item"],
            &["task", "update", "kanban", "assign", "board"],
            Vec::new(),
        ),
        tool(
            "task.move",
            "Move a repository Kanban task between todo, doing, review, or done while preserving its revision history.",
            &["move the task to doing", "mark the card done", "advance a Kanban task"],
            &["task", "move", "kanban", "status", "column"],
            Vec::new(),
        ),
        tool(
            "task.list",
            "List the repository Kanban task board. This is distinct from a Workflow DAG and from a workflow Blackboard evidence stream.",
            &["show the Kanban board", "list backlog tasks", "what work is in progress"],
            &["task", "list", "kanban", "board", "backlog"],
            Vec::new(),
        ),
        tool(
            "council.create",
            "Create a persisted multi-model agent council from typed member model/role pairs, chair, rounds, and evidence mode. Missing fields must be gathered first; a policy preview requires explicit approval before persistence.",
            &["create an agent council", "assemble models to deliberate", "save a review council"],
            &["council", "create", "models", "collaboration", "deliberation"],
            Vec::new(),
        ),
        tool(
            "council.run",
            "Run a named persisted agent council for an objective. Fan-out model requests are previewed for explicit approval; the result is persisted with a stable id and report link.",
            &["ask the council", "run the agent council", "have multiple models deliberate"],
            &["council", "run", "models", "deliberation", "result"],
            Vec::new(),
        ),
        tool(
            "council.result",
            "Retrieve a durable council result by stable result id or council name (latest), including its persisted report link.",
            &["show the council result", "open the latest council report", "retrieve council synthesis"],
            &["council", "result", "report", "synthesis", "retrieve"],
            Vec::new(),
        ),
        // The smarter-memory M2 core tool: an agent's only way to save a fact in its
        // own words. Its only effect is a `NoteAppended` on the run's own ledger — not
        // the filesystem, a command, the network, or a secret — so it requests no
        // capability (risk `Safe`), and it is CORE: offered to every run, unlike the
        // blackboard tools above (workflow-only).
        tool(
            "memory.remember",
            "Save a durable fact, decision, or learning to long-term memory in your own words \
             — one discrete fact per call, not a run summary.",
            &[
                "remember this fact",
                "save a decision to memory",
                "note a learning for future runs",
            ],
            &["memory", "remember", "fact", "decision", "learning"],
            Vec::new(),
        ),
        // The doc-writer tools (rubric #4). Like `blackboard.*` they target only
        // the knowledge fabric's document store — never the filesystem, a
        // command, or the network — so they request no capability (risk `Safe`);
        // the real gate on an agent's document write is the document's
        // collaboration mode. Registered so a "write this up" objective can
        // actually SELECT them: without a registry row the funnel had nothing to
        // rank, and the runtime never advertised them either.
        tool(
            "docs.create",
            "Draft a new knowledge-fabric document (title, scope, Markdown body) in Docs \
             Studio — the durable, block-structured place documentation lives, not a Markdown \
             file in the worktree.",
            &[
                "write this up as a document",
                "document this subsystem",
                "draft a design doc",
                "create a knowledge document",
                "write documentation for this",
            ],
            &[
                "docs",
                "document",
                "documentation",
                "write-up",
                "draft",
                "knowledge",
                "create",
            ],
            Vec::new(),
        ),
        tool(
            "docs.read",
            "Read a knowledge-fabric document as Markdown, or list the documents this run's \
             repository can see. Read before editing: block ids come from here.",
            &[
                "read the documentation",
                "list the knowledge documents",
                "open a document",
                "what docs exist for this",
            ],
            &[
                "docs",
                "document",
                "documentation",
                "read",
                "list",
                "open",
                "knowledge",
            ],
            Vec::new(),
        ),
        tool(
            "docs.edit",
            "Replace one block's text in a knowledge-fabric document. Whether the change lands \
             directly or as a reviewable suggestion is decided by the document's collaboration \
             mode, not by the caller.",
            &[
                "edit the documentation",
                "update a document",
                "fix a paragraph in the docs",
                "revise the knowledge document",
            ],
            &[
                "docs",
                "document",
                "documentation",
                "edit",
                "update",
                "revise",
                "block",
            ],
            Vec::new(),
        ),
        tool(
            "docs.suggest",
            "Propose a range replacement inside a document block for a human to accept or \
             reject, with an optional rationale — the reviewable path when the document should \
             not be edited directly.",
            &[
                "suggest a documentation change",
                "propose an edit to the docs for review",
                "flag stale documentation",
            ],
            &[
                "docs",
                "document",
                "documentation",
                "suggest",
                "propose",
                "review",
                "stale",
            ],
            Vec::new(),
        ),
        // The `graph.*` family had no registry entry at all, so the retrieval
        // funnel ranked it on its dotted name and one line of schema text. The
        // objective wording a model actually uses ("what breaks if I change
        // this", "wire this route to its handler") shares almost no lexical
        // surface with that, which is how a dispatchable family stays
        // unadvertised — the same gap round 3 found for `docs.*`.
        tool(
            "graph.callers_of",
            "List the symbols that call a function, method, or type, from the code graph.",
            &[
                "who calls this",
                "what uses this function",
                "before I change this signature",
                "find the call sites",
            ],
            &[
                "graph", "callers", "callsites", "usages", "references", "who calls",
            ],
            Vec::new(),
        ),
        tool(
            "graph.blast_radius",
            "List everything that transitively reaches a symbol — what breaks if it changes.",
            &[
                "what breaks if I change this",
                "impact of this change",
                "how far does this reach",
                "is this safe to rename",
            ],
            &[
                "graph",
                "blast",
                "radius",
                "impact",
                "breaks",
                "transitive",
                "dependents",
            ],
            Vec::new(),
        ),
        tool(
            "graph.tests_covering",
            "List the tests that exercise a file, by walking the code graph back from its symbols.",
            &[
                "which tests cover this",
                "what tests this file",
                "is this covered by tests",
            ],
            &[
                "graph", "tests", "covering", "coverage", "exercised", "verify",
            ],
            Vec::new(),
        ),
        tool(
            "graph.assert_edge",
            "Record a relationship between two symbols the parser cannot see — a route handler to \
             the service it dispatches to, a config key to the code that reads it, a test to the \
             behaviour it covers, a migration to the model it reshapes. Recorded as an agent \
             assertion, which never overrides what a parser or compiler resolved.",
            &[
                "record how these are connected",
                "the parser cannot see this link",
                "wire this route to its handler",
                "note that this test covers that",
                "teach the code graph",
            ],
            &[
                "graph",
                "edge",
                "assert",
                "relationship",
                "connect",
                "dispatch",
                "handler",
                "covers",
                "config",
                "migration",
            ],
            Vec::new(),
        ),
    ]
}

/// The built-in commands as governed registry items.
///
/// `/fix-ci` (Phase 3 STEP 3.2, now Phase 5 STEP 5.1.4): investigate a failed
/// GitHub check and prepare a verified change set. Registering it as a
/// [`RegistryItemKind::Command`] item makes it discoverable in the Skill Studio
/// alongside tools and skills; the invocation (`/fix-ci`) starts the declarative
/// `repair-github-check` workflow — the supervised investigator → implementer →
/// independent-reviewer flow — through the workflow engine, replacing the Phase-3
/// hard-coded objective template.
#[must_use]
pub fn builtin_commands() -> Vec<RegistryItem> {
    vec![
        command(
            "fix-ci",
            "Investigate a failed GitHub check and prepare a verified change set. \
             Invoked as `/fix-ci`; runs the declarative `repair-github-check` workflow — an \
             investigator inspects the check, an implementer proposes a patch in an isolated \
             worktree, the tests are re-run to verify it, an independent reviewer decides, and \
             — on approval — the pull request is updated.",
            &[
                "fix the failing CI",
                "repair a failed github check",
                "the ci is red",
                "make the checks pass",
            ],
            &["ci", "github", "check", "pull-request", "fix", "repair"],
            // `/fix-ci` runs git and reaches GitHub with the personal-mode token, so
            // its risk reflects both — the token bumps it to the highest tier.
            vec![
                CapabilityRequest::Command("git".into()),
                CapabilityRequest::Secret("github-token".into()),
            ],
        ),
        command(
            "update-docs",
            "Bring documentation in line with code changes (Phase 4 STEP 4.6). \
             Invoked as `/update-docs`; diffs documents' resolved `{{ symbol:… }}` \
             links against the live code graph and, for each stale reference, drafts \
             a Maintain-mode suggestion (never a direct edit) citing the causing \
             change for review.",
            &[
                "update the docs",
                "the documentation is stale",
                "docs reference an old symbol",
                "fix stale documentation",
            ],
            &["docs", "documentation", "staleness", "maintain", "symbol"],
            // Reads the repository to resolve symbols; proposes suggestions on
            // documents (no direct writes, no network).
            vec![CapabilityRequest::FilesystemRead(REPOSITORY_ROOT.into())],
        ),
    ]
}

/// Register (or refresh) every built-in tool and command.
///
/// Each is upserted at [`Scope::System`]; an existing registration of the same
/// identity has its `id`/`created_at` reused so ids stay stable across restarts.
/// Each upsert appends a `RegistryItemChanged` outbox row (via [`Registry::upsert`]).
pub async fn register_builtins(pool: &SqlitePool) -> Result<(), RegistryError> {
    let registry = Registry::new();
    for mut item in builtin_tools().into_iter().chain(builtin_commands()) {
        if let Some(existing) = registry
            .by_identity(pool, item.kind, &item.name, &item.scope)
            .await?
        {
            item.id = existing.id;
            item.created_at = existing.created_at;
        }
        registry.upsert(pool, &item).await?;
    }
    Ok(())
}

/// Build one built-in command [`RegistryItem`] (kind [`RegistryItemKind::Command`]).
/// Shares [`tool`]'s shape but is invoked, not called by the model as a tool.
fn command(
    name: &str,
    description: &str,
    intents: &[&str],
    keywords: &[&str],
    permissions: Vec<CapabilityRequest>,
) -> RegistryItem {
    RegistryItem {
        kind: RegistryItemKind::Command,
        ..tool(name, description, intents, keywords, permissions)
    }
}

/// Build one built-in tool [`RegistryItem`] with risk derived from its
/// permissions.
fn tool(
    name: &str,
    description: &str,
    intents: &[&str],
    keywords: &[&str],
    permissions: Vec<CapabilityRequest>,
) -> RegistryItem {
    let risk = RiskClass::from_permissions(&permissions);
    let now = Utc::now();
    RegistryItem {
        id: RegistryItemId::new(),
        kind: RegistryItemKind::Tool,
        name: name.to_string(),
        version: Version(BUILTIN_VERSION.to_string()),
        scope: Scope::System,
        description: description.to_string(),
        intents: intents.iter().map(|s| s.to_string()).collect(),
        keywords: keywords.iter().map(|s| s.to_string()).collect(),
        examples: Vec::new(),
        input_schema: None,
        output_schema: None,
        dependencies: Vec::new(),
        permissions,
        risk,
        provenance: Provenance::BuiltIn,
        trust: TrustMetadata {
            publisher: "codypendent".to_string(),
            signature_required: false,
            signature: None,
            tier: TrustTier::FirstParty,
        },
        status: RegistryStatus::Active,
        // Built-ins ship no scripts, so they are always runnable.
        content_hash: String::new(),
        executable: true,
        created_at: now,
        updated_at: now,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn coordination_tools_are_discoverable_with_distinct_language() {
        let tools = builtin_tools();
        let find = |name: &str| {
            tools
                .iter()
                .find(|item| item.name == name)
                .unwrap_or_else(|| panic!("missing built-in `{name}`"))
        };
        assert!(find("workflow.query")
            .description
            .contains("executable workflow"));
        for name in ["task.create", "task.update", "task.move", "task.list"] {
            assert!(find(name)
                .keywords
                .iter()
                .any(|keyword| keyword == "kanban"));
        }
        for name in ["council.create", "council.run", "council.result"] {
            assert!(find(name)
                .keywords
                .iter()
                .any(|keyword| keyword == "council"));
        }
        assert!(find("blackboard.post")
            .description
            .contains("typed artifact"));
    }
}
