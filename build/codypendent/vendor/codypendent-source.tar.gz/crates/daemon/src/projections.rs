//! Run/session projections backing the command pipeline (STEP 1.3).
//!
//! Projections are *derived* state: folding the same events must always produce
//! the same projection (invariant 5, property-tested in [`crate::commands`]).
//! The `runs` table **is** the run projection — the write path
//! ([`crate::commands`]) keeps it in step with the ledger inside the same
//! transaction that appends the run's events, so a committed run row and its
//! `RunStarted`/`RunStateChanged` events never disagree.
//!
//! Transaction-composable write helpers take `impl sqlx::SqliteExecutor<'_>`;
//! the explicit `*_with_outbox` pool wrappers create their own transaction for
//! standalone writers that must commit a control-plane snapshot atomically.
//! Read helpers take the pool because they run standalone (attach-time catch-up,
//! validation).

use std::str::FromStr;

use codypendent_protocol::ide::IdeContextUpdate;
use codypendent_protocol::{AgentMode, RunId, RunState, SessionId, SessionProjection};
use sqlx::SqlitePool;

/// The DB string for a [`RunState`] (the `runs.state` column). PascalCase to
/// match the variant names, consistent with the seed rows the sibling modules
/// write. Unknown / future variants collapse to `"Unknown"`.
pub fn run_state_to_db(state: RunState) -> &'static str {
    match state {
        RunState::Queued => "Queued",
        RunState::Preparing => "Preparing",
        RunState::Running => "Running",
        RunState::WaitingForApproval => "WaitingForApproval",
        RunState::WaitingForUserInput => "WaitingForUserInput",
        RunState::Paused => "Paused",
        RunState::Recovering => "Recovering",
        RunState::Completed => "Completed",
        RunState::Failed => "Failed",
        RunState::Cancelled => "Cancelled",
        // `Unknown` and any future non_exhaustive variant.
        _ => "Unknown",
    }
}

/// Parse a `runs.state` string back into a [`RunState`]; an unrecognized string
/// yields [`RunState::Unknown`] rather than erroring (forward-compatibility).
pub fn run_state_from_db(s: &str) -> RunState {
    match s {
        "Queued" => RunState::Queued,
        "Preparing" => RunState::Preparing,
        "Running" => RunState::Running,
        "WaitingForApproval" => RunState::WaitingForApproval,
        "WaitingForUserInput" => RunState::WaitingForUserInput,
        "Paused" => RunState::Paused,
        "Recovering" => RunState::Recovering,
        "Completed" => RunState::Completed,
        "Failed" => RunState::Failed,
        "Cancelled" => RunState::Cancelled,
        _ => RunState::Unknown,
    }
}

/// The DB string for an [`AgentMode`] (the `runs.mode` column).
pub fn agent_mode_to_db(mode: AgentMode) -> &'static str {
    match mode {
        AgentMode::Ask => "Ask",
        AgentMode::Explore => "Explore",
        AgentMode::Plan => "Plan",
        AgentMode::Build => "Build",
        AgentMode::Review => "Review",
        _ => "Unknown",
    }
}

/// Parse a `runs.mode` string back into an [`AgentMode`]; an unrecognized string
/// falls back to [`AgentMode::Build`] (the default preset).
pub fn agent_mode_from_db(s: &str) -> AgentMode {
    match s {
        "Ask" => AgentMode::Ask,
        "Explore" => AgentMode::Explore,
        "Plan" => AgentMode::Plan,
        "Review" => AgentMode::Review,
        _ => AgentMode::Build,
    }
}

/// Whether a run is in a terminal state (no further work). A terminal run is
/// excluded from a session's `active_runs`.
pub fn is_terminal(state: RunState) -> bool {
    matches!(
        state,
        RunState::Completed | RunState::Failed | RunState::Cancelled
    )
}

/// Insert a fresh run row in state [`RunState::Queued`]. STEP 1.3 only *creates*
/// the run; the agent loop that executes it is STEP 1.10. `model_policy` and
/// `budget_json` are the run's resolved policy/budget (the command carries
/// neither in Phase 1, so the write path supplies defaults).
pub async fn insert_run(
    exec: impl sqlx::SqliteExecutor<'_>,
    run_id: RunId,
    session_id: SessionId,
    objective: &str,
    mode: AgentMode,
    model_policy: &str,
    budget_json: &str,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        "INSERT INTO runs (id, session_id, objective, state, mode, model_policy, budget_json) \
         VALUES (?, ?, ?, ?, ?, ?, ?)",
    )
    .bind(run_id.to_string())
    .bind(session_id.to_string())
    .bind(objective)
    .bind(run_state_to_db(RunState::Queued))
    .bind(agent_mode_to_db(mode))
    .bind(model_policy)
    .bind(budget_json)
    .execute(exec)
    .await?;
    Ok(())
}

/// Insert a run through a pool-owned transaction and durably publish its
/// snapshot before commit when its session is eligible for control-plane sync.
pub async fn insert_run_with_outbox(
    pool: &SqlitePool,
    run_id: RunId,
    session_id: SessionId,
    objective: &str,
    mode: AgentMode,
    model_policy: &str,
    budget_json: &str,
) -> anyhow::Result<()> {
    let mut tx = pool.begin().await?;
    insert_run(
        &mut *tx,
        run_id,
        session_id,
        objective,
        mode,
        model_policy,
        budget_json,
    )
    .await?;
    crate::control_plane_sync::outbox::enqueue_run_snapshot(&mut tx, &run_id.to_string()).await?;
    tx.commit().await?;
    Ok(())
}

/// Move a run to a new [`RunState`]. A no-op update (run absent) is not an error
/// here; the write path validates run existence before calling this.
pub async fn set_run_state(
    exec: impl sqlx::SqliteExecutor<'_>,
    run_id: RunId,
    state: RunState,
) -> Result<(), sqlx::Error> {
    sqlx::query("UPDATE runs SET state = ? WHERE id = ?")
        .bind(run_state_to_db(state))
        .bind(run_id.to_string())
        .execute(exec)
        .await?;
    Ok(())
}

/// Pool-owned form of [`set_run_state`] that commits the authoritative state
/// change and its control-plane outbox snapshot together.
pub async fn set_run_state_with_outbox(
    pool: &SqlitePool,
    run_id: RunId,
    state: RunState,
) -> anyhow::Result<()> {
    let mut tx = pool.begin().await?;
    set_run_state(&mut *tx, run_id, state).await?;
    crate::control_plane_sync::outbox::enqueue_run_snapshot(&mut tx, &run_id.to_string()).await?;
    tx.commit().await?;
    Ok(())
}

/// Record the workspace lease a run bound its worktree under (Phase 5 T5), on
/// the reserved `runs.workspace_lease_id` column. This is the run→worktree
/// provenance link: the lease row ([`crate::worktrees`]) carries the concrete
/// `worktree_path`, so a run's real worktree is recoverable from its projection
/// alone. Idempotent-ish: called once when a writing run allocates its worktree;
/// a read-only run that keeps the repository root records nothing.
pub async fn set_run_workspace_lease(
    exec: impl sqlx::SqliteExecutor<'_>,
    run_id: RunId,
    lease_id: uuid::Uuid,
) -> Result<(), sqlx::Error> {
    sqlx::query("UPDATE runs SET workspace_lease_id = ? WHERE id = ?")
        .bind(lease_id.to_string())
        .bind(run_id.to_string())
        .execute(exec)
        .await?;
    Ok(())
}

/// The current [`RunState`] of a run, or `None` if there is no such run. Takes
/// a generic executor (not only the pool) so a caller can re-read the state
/// **inside its own write transaction** — the FP-3 fix reads the fresh,
/// under-the-write-lock state rather than trusting a read taken before that
/// transaction began.
pub async fn load_run_state(
    exec: impl sqlx::SqliteExecutor<'_>,
    run_id: RunId,
) -> anyhow::Result<Option<RunState>> {
    let row: Option<(String,)> = sqlx::query_as("SELECT state FROM runs WHERE id = ?")
        .bind(run_id.to_string())
        .fetch_optional(exec)
        .await?;
    Ok(row.map(|(state,)| run_state_from_db(&state)))
}

/// Transition a run to `state` **only if** its CURRENT state is one of
/// `legal_from` — a single atomic conditional `UPDATE`, never a separate
/// read-then-write — so a transition whose legality was checked before the
/// write transaction began cannot apply against a state that has since
/// changed underneath it (FP-3: the run-state lifecycle commands' guard used
/// to be check-then-act, validated outside the transaction that performed the
/// write). Returns the number of rows affected: `1` if the transition applied,
/// `0` if the run does not exist or its current state was not in `legal_from`
/// — the caller distinguishes those two (rare, and about to reject either way)
/// with a follow-up read.
pub async fn set_run_state_if_legal(
    exec: impl sqlx::SqliteExecutor<'_>,
    run_id: RunId,
    legal_from: &[RunState],
    state: RunState,
) -> Result<u64, sqlx::Error> {
    if legal_from.is_empty() {
        // No prior state makes this transition legal — nothing can match, so
        // skip the round-trip (and avoid emitting `... WHERE state IN ()`,
        // which is valid SQL but a wasted call).
        return Ok(0);
    }
    let placeholders = legal_from
        .iter()
        .map(|_| "?")
        .collect::<Vec<_>>()
        .join(", ");
    let sql = format!("UPDATE runs SET state = ? WHERE id = ? AND state IN ({placeholders})");
    let mut query = sqlx::query(&sql)
        .bind(run_state_to_db(state))
        .bind(run_id.to_string());
    for from in legal_from {
        query = query.bind(run_state_to_db(*from));
    }
    Ok(query.execute(exec).await?.rows_affected())
}

/// The session a run belongs to, or `None` if there is no such run. The write
/// path uses this to resolve the ledger a run-scoped command (`CancelRun`,
/// `QueueSteering`, ...) must append to.
pub async fn run_session(pool: &SqlitePool, run_id: RunId) -> anyhow::Result<Option<SessionId>> {
    let row: Option<(String,)> = sqlx::query_as("SELECT session_id FROM runs WHERE id = ?")
        .bind(run_id.to_string())
        .fetch_optional(pool)
        .await?;
    row.map(|(session,)| SessionId::from_str(&session))
        .transpose()
        .map_err(Into::into)
}

/// Build the compact [`SessionProjection`] the server sends in a `Catchup`
/// snapshot: session identity, `last_sequence` (`MAX(events.sequence)`), and the
/// ids of runs not in a terminal state. Ordered deterministically (`runs.id`
/// ascending) so the snapshot folds the same as the event ledger.
pub async fn session_projection(
    pool: &SqlitePool,
    session_id: SessionId,
) -> anyhow::Result<SessionProjection> {
    let meta: Option<(String, String)> =
        sqlx::query_as("SELECT title, state FROM sessions WHERE id = ?")
            .bind(session_id.to_string())
            .fetch_optional(pool)
            .await?;
    let (title, closed) = match meta {
        Some((title, state)) => (title, state == "closed"),
        None => (String::new(), false),
    };

    let (last_sequence,): (i64,) =
        sqlx::query_as("SELECT COALESCE(MAX(sequence), 0) FROM events WHERE session_id = ?")
            .bind(session_id.to_string())
            .fetch_one(pool)
            .await?;

    let runs: Vec<(String, String)> =
        sqlx::query_as("SELECT id, state FROM runs WHERE session_id = ? ORDER BY id ASC")
            .bind(session_id.to_string())
            .fetch_all(pool)
            .await?;
    let mut active_runs = Vec::new();
    for (id, state) in runs {
        if !is_terminal(run_state_from_db(&state)) {
            active_runs.push(RunId::from_str(&id)?);
        }
    }

    let approval_rows: Vec<(String, String, String, String)> = sqlx::query_as(
        "SELECT a.id, a.run_id, a.action_json, a.risk_json \
         FROM approvals a JOIN runs r ON r.id = a.run_id \
         WHERE r.session_id = ? AND a.state = 'pending' \
         ORDER BY a.requested_at ASC, a.id ASC",
    )
    .bind(session_id.to_string())
    .fetch_all(pool)
    .await?;
    let mut pending_approvals = Vec::with_capacity(approval_rows.len());
    for (approval_id, run_id, action_json, risk_json) in approval_rows {
        pending_approvals.push(codypendent_protocol::PendingApprovalProjection {
            approval_id: codypendent_protocol::ApprovalId::from_str(&approval_id)?,
            run_id: RunId::from_str(&run_id)?,
            action: serde_json::from_str(&action_json)?,
            risk: serde_json::from_str(&risk_json)?,
        });
    }

    let pending_prompts = crate::prompt_queue::snapshot_pool(pool, session_id).await?;

    Ok(SessionProjection {
        session_id,
        title,
        last_sequence: u64::try_from(last_sequence)?,
        active_runs,
        pending_approvals,
        pending_prompts,
        closed,
    })
}

/// Read a run's recorded mode from the DB, if present.
pub async fn load_run_mode(pool: &SqlitePool, run_id: RunId) -> anyhow::Result<Option<AgentMode>> {
    let row: Option<(String,)> = sqlx::query_as("SELECT mode FROM runs WHERE id = ?")
        .bind(run_id.to_string())
        .fetch_optional(pool)
        .await?;
    Ok(row.map(|(m,)| agent_mode_from_db(&m)))
}

/// Upsert the latest IDE context for a session (Phase 3 STEP 3.4). Latest-wins:
/// a session has at most one row, replaced on every `UpdateIdeContext`. Stored
/// outside the event ledger — IDE context is high-frequency, ephemeral, derived
/// state, not history.
pub async fn upsert_ide_context(
    pool: &SqlitePool,
    session_id: SessionId,
    update: &IdeContextUpdate,
    now: chrono::DateTime<chrono::Utc>,
) -> anyhow::Result<()> {
    let json = serde_json::to_string(update)?;
    sqlx::query(
        "INSERT INTO ide_context (session_id, update_json, updated_at) VALUES (?, ?, ?) \
         ON CONFLICT(session_id) DO UPDATE SET update_json = excluded.update_json, \
         updated_at = excluded.updated_at",
    )
    .bind(session_id.to_string())
    .bind(json)
    .bind(now.to_rfc3339())
    .execute(pool)
    .await?;
    Ok(())
}

/// Load the latest IDE context for a session, if any has been pushed.
pub async fn load_ide_context(
    pool: &SqlitePool,
    session_id: SessionId,
) -> anyhow::Result<Option<IdeContextUpdate>> {
    let row: Option<(String,)> =
        sqlx::query_as("SELECT update_json FROM ide_context WHERE session_id = ?")
            .bind(session_id.to_string())
            .fetch_optional(pool)
            .await?;
    match row {
        Some((json,)) => Ok(Some(serde_json::from_str(&json)?)),
        None => Ok(None),
    }
}

#[cfg(test)]
mod ide_context_tests {
    use super::*;
    use codypendent_protocol::ide::{DirtyBufferDigest, IdeContextUpdate};

    #[tokio::test]
    async fn ide_context_is_latest_wins() {
        let tmp = tempfile::tempdir().unwrap();
        let pool = crate::db::open_database(&tmp.path().join("db.sqlite"))
            .await
            .unwrap();
        let session = SessionId::new();
        // A session must exist for the FK.
        crate::ledger::create_session(&pool, session, "ide")
            .await
            .unwrap();

        assert!(load_ide_context(&pool, session).await.unwrap().is_none());

        let first = IdeContextUpdate {
            active_file: Some("a.rs".to_string()),
            ..Default::default()
        };
        upsert_ide_context(&pool, session, &first, chrono::Utc::now())
            .await
            .unwrap();

        let second = IdeContextUpdate {
            active_file: Some("b.rs".to_string()),
            dirty_buffers: vec![DirtyBufferDigest {
                path: "b.rs".to_string(),
                sha256: "abc".to_string(),
                byte_length: 5,
            }],
            ..Default::default()
        };
        upsert_ide_context(&pool, session, &second, chrono::Utc::now())
            .await
            .unwrap();

        // Latest wins: exactly one row, holding the second update.
        let loaded = load_ide_context(&pool, session).await.unwrap().unwrap();
        assert_eq!(loaded.active_file.as_deref(), Some("b.rs"));
        assert_eq!(loaded.dirty_buffers.len(), 1);
        let (count,): (i64,) = sqlx::query_as("SELECT COUNT(*) FROM ide_context")
            .fetch_one(&pool)
            .await
            .unwrap();
        assert_eq!(count, 1);
    }
}
