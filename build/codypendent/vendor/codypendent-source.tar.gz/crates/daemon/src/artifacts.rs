//! Content-addressed artifact store (STEP 1.4).
//!
//! Blobs are deduplicated by SHA-256 while every `put` records its own
//! per-occurrence metadata row. The two identifiers are deliberately
//! independent: identical bytes resolve to a single stored file (keyed by
//! `sha256` alone), but each occurrence is its own [`ArtifactRef`] with its own
//! [`ArtifactId`], classification, and [`Provenance`]. Classification checks
//! (model routing, export, display) always read the row of the specific ref in
//! hand — never a row looked up by hash — so the same bytes seen first as
//! `Internal` and later as `Secret` are two rows sharing one blob, and the
//! second never inherits the first's lower classification (RULE 1).
//!
//! Writes are atomic: bytes stream to `<root>/tmp/<uuid>` while being hashed,
//! then rename into place at `<root>/sha256/<xx>/<full-hex>`. A crash leaves
//! only `tmp/` garbage, which [`ArtifactStore::sweep_tmp`] removes on startup
//! (RULE 2).

use std::path::{Path, PathBuf};
use std::str::FromStr;

use chrono::{DateTime, Utc};
use codypendent_protocol::{
    ArtifactId, ArtifactRef, ClientId, CommandId, DataClassification, RunId,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sqlx::SqlitePool;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use uuid::Uuid;

/// Where an artifact's bytes came from, recorded once per occurrence and stored
/// verbatim in the `provenance_json` column.
///
/// This is a daemon-local record (not a wire type). It round-trips through JSON
/// so it can be persisted and read back unchanged. The uniform `observed_at`
/// captures when the daemon first saw the bytes; `source` describes the origin.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Provenance {
    /// What produced the bytes.
    pub source: ProvenanceSource,
    /// When the daemon first observed the bytes.
    pub observed_at: DateTime<Utc>,
}

/// The origin of an artifact's bytes. Internally tagged so it can grow new
/// variants without breaking stored rows.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum ProvenanceSource {
    /// Output captured from a tool invocation during a run.
    ToolOutput {
        /// The tool that produced the bytes, e.g. `shell.run`.
        tool: String,
        /// The run the tool executed within.
        run_id: RunId,
    },
    /// Content supplied directly by a human (an upload or paste).
    UserUpload,
    /// Bytes produced by the daemon itself (chronicles, snapshots, recovery
    /// exports); `detail` names the producing subsystem.
    System {
        /// A short description of the producing subsystem.
        detail: String,
    },
}

impl Provenance {
    /// Provenance for output captured from a tool during a run, observed now.
    pub fn tool_output(tool: impl Into<String>, run_id: RunId) -> Self {
        Self {
            source: ProvenanceSource::ToolOutput {
                tool: tool.into(),
                run_id,
            },
            observed_at: Utc::now(),
        }
    }

    /// Provenance for content supplied directly by a human, observed now.
    pub fn user_upload() -> Self {
        Self {
            source: ProvenanceSource::UserUpload,
            observed_at: Utc::now(),
        }
    }

    /// Provenance for bytes produced by the daemon itself, observed now.
    pub fn system(detail: impl Into<String>) -> Self {
        Self {
            source: ProvenanceSource::System {
                detail: detail.into(),
            },
            observed_at: Utc::now(),
        }
    }
}

/// A content-addressed blob store rooted at `<data_dir>/artifacts`.
///
/// Layout under `root`:
/// - `sha256/<xx>/<full-hex>` — the deduplicated blobs (`<xx>` = first two hex
///   chars of the digest, to fan the directory out).
/// - `tmp/<uuid>` — in-flight writes awaiting the atomic rename into `sha256/`.
#[derive(Debug, Clone)]
pub struct ArtifactStore {
    root: PathBuf,
}

/// The stable result of one idempotent client upload. A retry may carry a new
/// transport message and even a newly generated command id; the reply still
/// uses the command id/result recorded by the first accepted occurrence.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IdempotentArtifactUpload {
    pub command_id: CommandId,
    pub artifact: ArtifactRef,
}

#[derive(Debug, thiserror::Error)]
pub enum ArtifactUploadError {
    #[error("idempotency key was already used by a different client or artifact upload")]
    Conflict,
    #[error(transparent)]
    Store(#[from] anyhow::Error),
}

/// Create `path` (and its missing parents) at mode 0700.
///
/// The blob tree may be rooted somewhere another local account can create — the
/// daemon has a `std::env::temp_dir()` fallback — so a directory created at the
/// default 0755 lets any local user list and read content-addressed blobs whose
/// rows are classified `Secret`. Directories that already exist are left alone:
/// silently widening or narrowing an existing directory's mode would be a
/// decision about a path this store does not own.
async fn create_private_dir_all(path: &Path) -> std::io::Result<()> {
    #[cfg(unix)]
    {
        // `mode` here is `tokio::fs::DirBuilder`'s own Unix-only method.
        let mut builder = tokio::fs::DirBuilder::new();
        builder.recursive(true).mode(0o700);
        return builder.create(path).await;
    }
    #[cfg(not(unix))]
    tokio::fs::create_dir_all(path).await
}

/// Create `path` for writing at mode 0600, failing if it already exists.
///
/// The mode is set by `open(2)` itself rather than by a following `chmod`, so
/// there is no window in which the file exists world-readable. `create_new`
/// because the caller names a fresh v7 UUID: an existing file at that path is
/// something else, and truncating it is not this function's business.
async fn private_file_create(path: &Path) -> std::io::Result<tokio::fs::File> {
    let mut options = tokio::fs::OpenOptions::new();
    options.write(true).create_new(true);
    // `tokio::fs::OpenOptions::mode` is the Unix-only inherent method — the
    // std extension trait is not needed (and importing it warns as unused).
    #[cfg(unix)]
    options.mode(0o600);
    options.open(path).await
}

impl ArtifactStore {
    /// Create a store rooted at `root` (`<data_dir>/artifacts`). The `sha256/`
    /// and `tmp/` subdirectories are created lazily on the first [`put`].
    ///
    /// [`put`]: ArtifactStore::put
    pub fn new(root: PathBuf) -> Self {
        Self { root }
    }

    fn tmp_dir(&self) -> PathBuf {
        self.root.join("tmp")
    }

    /// On-disk path for a blob with the given lowercase-hex SHA-256.
    fn blob_path(&self, sha256: &str) -> PathBuf {
        self.root.join("sha256").join(&sha256[..2]).join(sha256)
    }

    /// Store `bytes` and record a fresh metadata row for this occurrence.
    ///
    /// Streams `bytes` to `<root>/tmp/<uuid>` while hashing, then atomically
    /// renames the temp file to its content-addressed path. If that blob
    /// already exists the write is skipped (the temp file is removed) but a new
    /// `artifacts` row is still inserted with its own [`ArtifactId`], the given
    /// `classification`, and `provenance`. Returns the [`ArtifactRef`] built
    /// from this row.
    pub async fn put(
        &self,
        pool: &SqlitePool,
        media_type: &str,
        classification: DataClassification,
        provenance: Provenance,
        bytes: &[u8],
    ) -> anyhow::Result<ArtifactRef> {
        let sha256 = self.store_blob(bytes).await?;

        // Per-occurrence metadata row: its own id, this classification and
        // provenance — never inherited from an earlier occurrence.
        let id = ArtifactId::new();
        let byte_length = bytes.len() as u64;
        let created_at = Utc::now().to_rfc3339();
        let mut tx = pool.begin().await?;
        sqlx::query(
            "INSERT INTO artifacts \
             (id, sha256, media_type, byte_length, classification, created_at, provenance_json) \
             VALUES (?, ?, ?, ?, ?, ?, ?)",
        )
        .bind(id.to_string())
        .bind(&sha256)
        .bind(media_type)
        .bind(i64::try_from(byte_length)?)
        .bind(classification_to_str(classification))
        .bind(&created_at)
        .bind(serde_json::to_string(&provenance)?)
        .execute(&mut *tx)
        .await?;
        crate::control_plane_sync::outbox::enqueue_artifact_snapshot(&mut tx, &id.to_string())
            .await?;
        tx.commit().await?;

        Ok(ArtifactRef {
            id,
            media_type: media_type.to_string(),
            byte_length,
            sha256,
            sensitivity: classification,
        })
    }

    /// Store `bytes` and record a fresh metadata row owned by `owner_uid`.
    pub async fn put_owned(
        &self,
        pool: &SqlitePool,
        owner_uid: u32,
        media_type: &str,
        classification: DataClassification,
        provenance: Provenance,
        bytes: &[u8],
    ) -> anyhow::Result<ArtifactRef> {
        let sha256 = self.store_blob(bytes).await?;

        let id = ArtifactId::new();
        let byte_length = bytes.len() as u64;
        let created_at = Utc::now().to_rfc3339();
        let mut tx = pool.begin().await?;
        sqlx::query(
            "INSERT INTO artifacts \
             (id, sha256, media_type, byte_length, classification, created_at, provenance_json, owner_uid) \
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        )
        .bind(id.to_string())
        .bind(&sha256)
        .bind(media_type)
        .bind(i64::try_from(byte_length)?)
        .bind(classification_to_str(classification))
        .bind(&created_at)
        .bind(serde_json::to_string(&provenance)?)
        .bind(i64::from(owner_uid))
        .execute(&mut *tx)
        .await?;
        crate::control_plane_sync::outbox::enqueue_artifact_snapshot(&mut tx, &id.to_string())
            .await?;
        tx.commit().await?;

        Ok(ArtifactRef {
            id,
            media_type: media_type.to_string(),
            byte_length,
            sha256,
            sensitivity: classification,
        })
    }

    /// Store a controller upload exactly once for `idempotency_key`.
    ///
    /// The blob publish may precede the SQL transaction (an unreferenced
    /// content-addressed blob is harmless and sweepable), but the artifact
    /// occurrence row and replay journal commit atomically. The server
    /// serializes this method's lookup/insert sequence, while the unique key is
    /// the durable cross-restart authority.
    #[allow(clippy::too_many_arguments)]
    pub async fn put_user_upload_idempotent(
        &self,
        pool: &SqlitePool,
        client_id: ClientId,
        owner_uid: u32,
        command_id: CommandId,
        idempotency_key: &str,
        request_hash: &str,
        media_type: &str,
        classification: DataClassification,
        bytes: &[u8],
    ) -> Result<IdempotentArtifactUpload, ArtifactUploadError> {
        if let Some(existing) = lookup_upload(pool, idempotency_key)
            .await
            .map_err(ArtifactUploadError::Store)?
        {
            if existing.client_id != client_id.to_string() || existing.request_hash != request_hash
            {
                return Err(ArtifactUploadError::Conflict);
            }
            return existing.into_result().map_err(ArtifactUploadError::Store);
        }

        let sha256 = self
            .store_blob(bytes)
            .await
            .map_err(ArtifactUploadError::Store)?;
        let artifact_id = ArtifactId::new();
        let byte_length = u64::try_from(bytes.len()).map_err(anyhow::Error::from)?;
        let created_at = Utc::now().to_rfc3339();
        let mut tx = pool.begin().await.map_err(anyhow::Error::from)?;
        sqlx::query(
            "INSERT INTO artifacts \
             (id, sha256, media_type, byte_length, classification, created_at, provenance_json, owner_uid) \
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        )
        .bind(artifact_id.to_string())
        .bind(&sha256)
        .bind(media_type)
        .bind(i64::try_from(byte_length).map_err(anyhow::Error::from)?)
        .bind(classification_to_str(classification))
        .bind(&created_at)
        .bind(serde_json::to_string(&Provenance::user_upload()).map_err(anyhow::Error::from)?)
        .bind(i64::from(owner_uid))
        .execute(&mut *tx)
        .await
        .map_err(anyhow::Error::from)?;
        sqlx::query(
            "INSERT INTO artifact_upload_commands \
             (idempotency_key, client_id, command_id, request_hash, artifact_id, created_at) \
             VALUES (?, ?, ?, ?, ?, ?)",
        )
        .bind(idempotency_key)
        .bind(client_id.to_string())
        .bind(command_id.to_string())
        .bind(request_hash)
        .bind(artifact_id.to_string())
        .bind(&created_at)
        .execute(&mut *tx)
        .await
        .map_err(anyhow::Error::from)?;
        crate::control_plane_sync::outbox::enqueue_artifact_snapshot(
            &mut tx,
            &artifact_id.to_string(),
        )
        .await
        .map_err(anyhow::Error::from)?;
        tx.commit().await.map_err(anyhow::Error::from)?;

        Ok(IdempotentArtifactUpload {
            command_id,
            artifact: ArtifactRef {
                id: artifact_id,
                media_type: media_type.to_string(),
                byte_length,
                sha256,
                sensitivity: classification,
            },
        })
    }

    async fn store_blob(&self, bytes: &[u8]) -> anyhow::Result<String> {
        // `bytes` is already fully in memory, so hash it directly — no disk
        // write is needed to learn the content address. A dedup hit therefore
        // touches no temp file at all.
        let mut hasher = Sha256::new();
        hasher.update(bytes);
        let sha256 = hex::encode(hasher.finalize());
        let blob_path = self.blob_path(&sha256);
        if !tokio::fs::try_exists(&blob_path).await? {
            let tmp_dir = self.tmp_dir();
            create_private_dir_all(&tmp_dir).await?;
            let tmp_path = tmp_dir.join(Uuid::now_v7().to_string());
            {
                // The temp file becomes the blob verbatim (rename, not copy), so
                // its mode IS the blob's mode. `File::create` is 0666 & umask —
                // 0644 on a default umask — and a blob can carry `Secret`
                // classified content, so every local account could read what the
                // classification says is restricted. Mode 0600 is applied AT
                // creation, the way `daemon.secret` does it: a create-then-chmod
                // leaves the bytes world-readable for the width of the write.
                let mut file = private_file_create(&tmp_path).await?;
                file.write_all(bytes).await?;
                file.flush().await?;
                file.sync_all().await?;
            }
            if let Some(parent) = blob_path.parent() {
                create_private_dir_all(parent).await?;
            }
            tokio::fs::rename(&tmp_path, &blob_path).await?;
        }
        Ok(sha256)
    }

    /// Open the blob backing the artifact row `id` for reading.
    pub async fn open(&self, pool: &SqlitePool, id: ArtifactId) -> anyhow::Result<tokio::fs::File> {
        let sha256 = self.lookup_sha256(pool, id).await?;
        let path = self.blob_path(&sha256);
        let file = tokio::fs::File::open(&path).await?;
        Ok(file)
    }

    /// Read all bytes backing the artifact row `id`.
    pub async fn read_bytes(&self, pool: &SqlitePool, id: ArtifactId) -> anyhow::Result<Vec<u8>> {
        let sha256 = self.lookup_sha256(pool, id).await?;
        let path = self.blob_path(&sha256);
        let bytes = tokio::fs::read(&path).await?;
        Ok(bytes)
    }

    /// The classification RECORDED for `id` when it was stored.
    ///
    /// An [`ArtifactRef`] travels on the wire, so its `sensitivity` is whatever
    /// the sender wrote — a client may cite a real artifact id under a lower
    /// classification than the one the daemon stored. Any gate that decides
    /// where those bytes may travel must ask this, never the ref. An
    /// unrecognised (or future) column value reads back `Unknown`, which the
    /// protocol ranks above `Secret`, so a corrupted row fails closed.
    pub async fn classification(
        &self,
        pool: &SqlitePool,
        id: ArtifactId,
    ) -> anyhow::Result<DataClassification> {
        let row: Option<(String,)> =
            sqlx::query_as("SELECT classification FROM artifacts WHERE id = ?")
                .bind(id.to_string())
                .fetch_optional(pool)
                .await?;
        let (stored,) = row.ok_or_else(|| anyhow::anyhow!("artifact {id} is not in the store"))?;
        Ok(match stored.as_str() {
            "Public" => DataClassification::Public,
            "Internal" => DataClassification::Internal,
            "Confidential" => DataClassification::Confidential,
            "Secret" => DataClassification::Secret,
            _ => DataClassification::Unknown,
        })
    }

    /// Re-hash the blob backing `id` and report whether it matches the SHA-256
    /// recorded in the artifact row (integrity check).
    pub async fn verify(&self, pool: &SqlitePool, id: ArtifactId) -> anyhow::Result<bool> {
        let stored = self.lookup_sha256(pool, id).await?;
        let actual = hash_file(&self.blob_path(&stored)).await?;
        Ok(actual == stored)
    }

    /// Stored ownership for authorization. `None` is either absent or a legacy
    /// daemon-owned row; callers distinguish those by separately opening the
    /// row and apply their daemon-uid adoption policy.
    pub async fn owner_uid(
        &self,
        pool: &SqlitePool,
        id: ArtifactId,
    ) -> anyhow::Result<Option<u32>> {
        let owner: Option<Option<i64>> =
            sqlx::query_scalar("SELECT owner_uid FROM artifacts WHERE id = ?")
                .bind(id.to_string())
                .fetch_optional(pool)
                .await?;
        owner
            .flatten()
            .map(u32::try_from)
            .transpose()
            .map_err(Into::into)
    }

    pub async fn sha256(&self, pool: &SqlitePool, id: ArtifactId) -> anyhow::Result<String> {
        self.lookup_sha256(pool, id).await
    }

    /// Delete leftover files under `<root>/tmp/` — crash garbage from writes
    /// that never reached their atomic rename. Called on startup. A missing
    /// `tmp/` directory is not an error.
    pub async fn sweep_tmp(&self) -> anyhow::Result<()> {
        let tmp_dir = self.tmp_dir();
        let mut entries = match tokio::fs::read_dir(&tmp_dir).await {
            Ok(entries) => entries,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(()),
            Err(e) => return Err(e.into()),
        };
        while let Some(entry) = entries.next_entry().await? {
            let path = entry.path();
            if entry.file_type().await?.is_dir() {
                tokio::fs::remove_dir_all(&path).await?;
            } else {
                tokio::fs::remove_file(&path).await?;
            }
        }
        Ok(())
    }

    /// Resolve the stored SHA-256 for an artifact row by id.
    async fn lookup_sha256(&self, pool: &SqlitePool, id: ArtifactId) -> anyhow::Result<String> {
        let row: Option<(String,)> = sqlx::query_as("SELECT sha256 FROM artifacts WHERE id = ?")
            .bind(id.to_string())
            .fetch_optional(pool)
            .await?;
        row.map(|(sha256,)| sha256)
            .ok_or_else(|| anyhow::anyhow!("no artifact row for id {id}"))
    }
}

struct StoredUpload {
    client_id: String,
    command_id: String,
    request_hash: String,
    artifact_id: String,
    sha256: String,
    media_type: String,
    byte_length: i64,
    classification: String,
}

impl StoredUpload {
    fn into_result(self) -> anyhow::Result<IdempotentArtifactUpload> {
        Ok(IdempotentArtifactUpload {
            command_id: CommandId::from_str(&self.command_id)?,
            artifact: ArtifactRef {
                id: ArtifactId::from_str(&self.artifact_id)?,
                media_type: self.media_type,
                byte_length: u64::try_from(self.byte_length)?,
                sha256: self.sha256,
                sensitivity: classification_from_str(&self.classification),
            },
        })
    }
}

async fn lookup_upload(
    pool: &SqlitePool,
    idempotency_key: &str,
) -> anyhow::Result<Option<StoredUpload>> {
    type Row = (String, String, String, String, String, String, i64, String);
    let row: Option<Row> = sqlx::query_as(
        "SELECT u.client_id, u.command_id, u.request_hash, a.id, a.sha256, \
                a.media_type, a.byte_length, a.classification \
         FROM artifact_upload_commands u JOIN artifacts a ON a.id = u.artifact_id \
         WHERE u.idempotency_key = ?",
    )
    .bind(idempotency_key)
    .fetch_optional(pool)
    .await?;
    Ok(row.map(
        |(
            client_id,
            command_id,
            request_hash,
            artifact_id,
            sha256,
            media_type,
            byte_length,
            classification,
        )| StoredUpload {
            client_id,
            command_id,
            request_hash,
            artifact_id,
            sha256,
            media_type,
            byte_length,
            classification,
        },
    ))
}

/// The lowercase-hex SHA-256 of a file's contents, hashed by streaming so large
/// blobs are never held in memory whole.
async fn hash_file(path: &Path) -> anyhow::Result<String> {
    let mut file = tokio::fs::File::open(path).await?;
    let mut hasher = Sha256::new();
    let mut buf = vec![0u8; 64 * 1024];
    loop {
        let n = file.read(&mut buf).await?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    Ok(hex::encode(hasher.finalize()))
}

/// Encode a [`DataClassification`] as the plain tag stored in the `artifacts`
/// row's `classification` column. Any future (or `Unknown`) variant is stored
/// as `"Unknown"`, matching the protocol's "treat unknown as most restrictive"
/// rule.
fn classification_to_str(classification: DataClassification) -> &'static str {
    match classification {
        DataClassification::Public => "Public",
        DataClassification::Internal => "Internal",
        DataClassification::Confidential => "Confidential",
        DataClassification::Secret => "Secret",
        _ => "Unknown",
    }
}

fn classification_from_str(classification: &str) -> DataClassification {
    match classification {
        "Public" => DataClassification::Public,
        "Internal" => DataClassification::Internal,
        "Confidential" => DataClassification::Confidential,
        "Secret" => DataClassification::Secret,
        _ => DataClassification::Unknown,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    async fn test_pool(dir: &Path) -> SqlitePool {
        crate::db::open_database(&dir.join("test.db"))
            .await
            .expect("open database")
    }

    /// Count regular files anywhere under `root` (recursively).
    fn count_files(root: &Path) -> usize {
        let mut total = 0;
        if let Ok(entries) = std::fs::read_dir(root) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.is_dir() {
                    total += count_files(&path);
                } else {
                    total += 1;
                }
            }
        }
        total
    }

    /// A blob can carry `Secret` classified content, and the file the daemon
    /// leaves on disk is the whole of the protection. `File::create` is
    /// `0666 & umask` — 0644 on a stock umask — so every local account could
    /// read what the classification says is restricted, and the blob tree's own
    /// directories were 0755 on top of it.
    #[tokio::test]
    #[cfg(unix)]
    async fn a_stored_blob_and_its_directories_are_not_readable_by_other_accounts() {
        use std::os::unix::fs::PermissionsExt as _;

        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let root = dir.path().join("artifacts");
        let store = ArtifactStore::new(root.clone());

        let reference = store
            .put(
                &pool,
                "text/plain",
                DataClassification::Secret,
                Provenance::user_upload(),
                b"an api key, a transcript, a private diff",
            )
            .await
            .unwrap();

        let blob = store.blob_path(&reference.sha256);
        let mode = std::fs::metadata(&blob).unwrap().permissions().mode() & 0o777;
        assert_eq!(
            mode, 0o600,
            "a Secret-classified blob must not be group- or world-readable"
        );

        for directory in [root.join("sha256"), blob.parent().unwrap().to_path_buf()] {
            let mode = std::fs::metadata(&directory).unwrap().permissions().mode() & 0o777;
            assert_eq!(
                mode & 0o077,
                0,
                "{} must not be traversable by other accounts (mode {mode:o})",
                directory.display()
            );
        }
    }

    #[tokio::test]
    async fn put_open_round_trip() {
        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let store = ArtifactStore::new(dir.path().join("artifacts"));

        let bytes = b"hello content-addressed world";
        let reference = store
            .put(
                &pool,
                "text/plain",
                DataClassification::Internal,
                Provenance::user_upload(),
                bytes,
            )
            .await
            .unwrap();
        assert_eq!(reference.byte_length, bytes.len() as u64);

        let mut file = store.open(&pool, reference.id).await.unwrap();
        let mut read_back = Vec::new();
        file.read_to_end(&mut read_back).await.unwrap();
        assert_eq!(read_back, bytes);
    }

    #[tokio::test]
    async fn user_upload_retry_replays_the_original_occurrence() {
        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let store = ArtifactStore::new(dir.path().join("artifacts"));
        let client = ClientId::new();
        let command = CommandId::new();

        let first = store
            .put_user_upload_idempotent(
                &pool,
                client,
                501,
                command,
                "voice-upload-1",
                "request-hash",
                "audio/wav",
                DataClassification::Confidential,
                b"RIFF idempotent voice",
            )
            .await
            .unwrap();
        let replay = store
            .put_user_upload_idempotent(
                &pool,
                client,
                501,
                CommandId::new(),
                "voice-upload-1",
                "request-hash",
                "audio/wav",
                DataClassification::Confidential,
                b"RIFF idempotent voice",
            )
            .await
            .unwrap();

        assert_eq!(replay, first);
        let (rows,): (i64,) = sqlx::query_as("SELECT COUNT(*) FROM artifacts")
            .fetch_one(&pool)
            .await
            .unwrap();
        assert_eq!(rows, 1);
    }

    #[tokio::test]
    async fn user_upload_retry_rejects_a_different_client_or_request() {
        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let store = ArtifactStore::new(dir.path().join("artifacts"));
        let client = ClientId::new();
        store
            .put_user_upload_idempotent(
                &pool,
                client,
                501,
                CommandId::new(),
                "voice-upload-2",
                "request-hash",
                "audio/wav",
                DataClassification::Confidential,
                b"RIFF",
            )
            .await
            .unwrap();

        assert!(matches!(
            store
                .put_user_upload_idempotent(
                    &pool,
                    ClientId::new(),
                    501,
                    CommandId::new(),
                    "voice-upload-2",
                    "request-hash",
                    "audio/wav",
                    DataClassification::Confidential,
                    b"RIFF",
                )
                .await,
            Err(ArtifactUploadError::Conflict)
        ));
        assert!(matches!(
            store
                .put_user_upload_idempotent(
                    &pool,
                    client,
                    501,
                    CommandId::new(),
                    "voice-upload-2",
                    "different-request",
                    "audio/wav",
                    DataClassification::Confidential,
                    b"different",
                )
                .await,
            Err(ArtifactUploadError::Conflict)
        ));
    }

    #[tokio::test]
    async fn verify_returns_true_for_intact_blob() {
        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let store = ArtifactStore::new(dir.path().join("artifacts"));

        let reference = store
            .put(
                &pool,
                "application/octet-stream",
                DataClassification::Confidential,
                Provenance::system("unit-test"),
                b"bytes to verify",
            )
            .await
            .unwrap();

        assert!(store.verify(&pool, reference.id).await.unwrap());
    }

    #[tokio::test]
    async fn dedup_blob_but_per_occurrence_rows() {
        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let store = ArtifactStore::new(dir.path().join("artifacts"));

        let bytes = b"identical bytes seen twice";
        let internal = store
            .put(
                &pool,
                "text/plain",
                DataClassification::Internal,
                Provenance::system("first"),
                bytes,
            )
            .await
            .unwrap();
        let secret = store
            .put(
                &pool,
                "text/plain",
                DataClassification::Secret,
                Provenance::system("second"),
                bytes,
            )
            .await
            .unwrap();

        // (a) exactly one blob file on disk under sha256/.
        let blob_root = dir.path().join("artifacts").join("sha256");
        assert_eq!(count_files(&blob_root), 1);

        // (b) two distinct rows, same hash, different ids.
        assert_eq!(internal.sha256, secret.sha256);
        assert_ne!(internal.id, secret.id);
        let (rows,): (i64,) = sqlx::query_as("SELECT COUNT(*) FROM artifacts WHERE sha256 = ?")
            .bind(&internal.sha256)
            .fetch_one(&pool)
            .await
            .unwrap();
        assert_eq!(rows, 2);

        // (c) the second ref keeps Secret; it did NOT inherit Internal — on the
        //     ref, in the returned value, and as stored in its own row.
        assert_eq!(internal.sensitivity, DataClassification::Internal);
        assert_eq!(secret.sensitivity, DataClassification::Secret);
        let (stored_class,): (String,) =
            sqlx::query_as("SELECT classification FROM artifacts WHERE id = ?")
                .bind(secret.id.to_string())
                .fetch_one(&pool)
                .await
                .unwrap();
        assert_eq!(stored_class, "Secret");
    }

    /// An `ArtifactRef` is wire data: a client can cite a real artifact id under
    /// a classification it never had. Any gate deciding where those bytes may
    /// travel (off-device transcription, above all) must read the stored row,
    /// which is what `classification()` exists to provide.
    #[tokio::test]
    async fn stored_classification_ignores_what_a_ref_later_claims() {
        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let store = ArtifactStore::new(dir.path().join("artifacts"));

        let secret = store
            .put(
                &pool,
                "audio/wav",
                DataClassification::Secret,
                Provenance::system("voice capture"),
                b"RIFF....dictated notes",
            )
            .await
            .unwrap();

        // The forged ref: same id, downgraded classification.
        let mut forged = secret.clone();
        forged.sensitivity = DataClassification::Public;
        assert_eq!(forged.id, secret.id);

        assert_eq!(
            store.classification(&pool, forged.id).await.unwrap(),
            DataClassification::Secret,
            "the store must report what it recorded, not what the ref claims"
        );
    }

    /// A row whose classification column is unreadable (a future variant, or
    /// corruption) must fail closed: `Unknown` ranks above `Secret`.
    #[tokio::test]
    async fn an_unrecognised_stored_classification_reads_back_as_unknown() {
        let dir = tempdir().unwrap();
        let pool = test_pool(dir.path()).await;
        let store = ArtifactStore::new(dir.path().join("artifacts"));

        let stored = store
            .put(
                &pool,
                "audio/wav",
                DataClassification::Internal,
                Provenance::system("voice capture"),
                b"RIFF....",
            )
            .await
            .unwrap();
        sqlx::query("UPDATE artifacts SET classification = ? WHERE id = ?")
            .bind("SomethingNewerThanThisBuild")
            .bind(stored.id.to_string())
            .execute(&pool)
            .await
            .unwrap();

        assert_eq!(
            store.classification(&pool, stored.id).await.unwrap(),
            DataClassification::Unknown
        );
    }

    #[tokio::test]
    async fn sweep_tmp_removes_stray_files() {
        let dir = tempdir().unwrap();
        let store = ArtifactStore::new(dir.path().join("artifacts"));

        let tmp_dir = dir.path().join("artifacts").join("tmp");
        tokio::fs::create_dir_all(&tmp_dir).await.unwrap();
        let stray = tmp_dir.join("leftover-from-crash");
        tokio::fs::write(&stray, b"garbage").await.unwrap();
        assert!(stray.exists());

        store.sweep_tmp().await.unwrap();

        assert!(!stray.exists());
        // The tmp directory itself is retained (empty).
        assert!(tmp_dir.exists());
    }

    #[test]
    fn provenance_round_trips_through_json() {
        let cases = [
            Provenance::tool_output("shell.run", RunId::new()),
            Provenance::user_upload(),
            Provenance::system("chronicle-export"),
        ];
        for original in cases {
            let json = serde_json::to_string(&original).unwrap();
            let parsed: Provenance = serde_json::from_str(&json).unwrap();
            assert_eq!(original, parsed);
        }
    }
}
